/**
 * @author waleed
 *
 * 07-Jan-2022
 */

package com.waleed.training;

public class InheritanceDemo {

	public static void main(String[] args) {
		
		Aishwarya aishwarya = new Aishwarya();
		aishwarya.eat();
		aishwarya.breathe();
		aishwarya.run();
		
		System.out.println("-------------------------------");
		
		Akarsh akarsh = new Akarsh();
		akarsh.eat();
		akarsh.breathe();
		akarsh.run();
		akarsh.swim();
		
		Bindu bindu = new Bindu();
//		bindu.eat();//Can't call eat from bindu

	}

}

class Bindu{
	
}


//final class Human{//final classes can't even be inherited!
class Human{
	void eat() {
		System.out.println("Generic way of eating...");
	}
	
//	final int LENGTH = 90;
	
	final void breathe() {//final methods cannot be overridden
		System.out.println("Generic way of how Humans breathe...");
	}
	
	
	void run() {
		System.out.println("Generic way of running...");
	}
}

class Aishwarya extends Human{
	
	@Override
	public void run() {
		System.out.println("Aishwarya's own way of running...");
	}
	
//	void breathe() {//Can't do this now, because breathe in Human is final
//		
//	}
}

class Akarsh extends Human{
	@Override
	void eat() {
		System.out.println("Akarsh's own way of eating...");
	}
	
	@Override
	void run() {
		System.out.println("Akarsh's own way of running...");
	}
	
	
	void swim() {
		System.out.println("Akarsh can swim really well...");
	}
}

// #1. Scope of the overriding method in the sub class can 
// be the same as of the the overridden method in
// the super type or it can be broader but never narrowed down 







