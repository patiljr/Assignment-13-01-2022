/**
 * @author waleed
 *
 * 10-Jan-2022
 */

package com.waleed.training.inter;

public class WorkingWithInterfaces {

	public static void main(String[] args) {
		
//		new Sindhu().breathe();
		
		Human []refs = new Human[3];//Works
		refs[0] = new Neelu();
		refs[1] = new Sindhu();
		refs[2] = new Sindhu();
		
//		Traverse through the array with a loop
		for(Human ref : refs) {
			ref.eat();
			ref.breathe();
			ref.walk();
			ref.smile();
			if(ref instanceof Neelu)//Checks for IS-A
				((Neelu)ref).sing();//Neelu's sing()
			System.out.println("--------------------------");
		}
		
		
		
		
//		Human ref = new Neelu();
//		ref.breathe();
//		ref.eat();
////		ref.sing();//doesn't work
//		
//		ref = new Sindhu();
//		
//		ref.breathe();
//		ref.eat();
	}

}

interface Human{
	void eat();
	void walk();
	void breathe();
	default void smile() {//Works starting with Java 8
		System.out.println("The smile was added later on");
	}
}

interface Boxer extends Human{
	void fight();
}

interface Employee{
	void workForWages();
	default void smile() {
		System.out.println("EMployee's smile...");
	}
}

class Neelu implements Human{
	@Override
	public void eat() {
		System.out.println("Neelu's own version of eat...");
	}
	
	@Override
	public void walk() {
		System.out.println("Neelu's walk...");
	}
	@Override
	public void breathe() {
		System.out.println("Neelu's breathe...");
	}
	
	void sing() {
		System.out.println("Neelu can sing...");
	}
}

class Sindhu implements Human, Employee{
	@Override
	public void eat() {
		System.out.println("Sindhu's own version of eat...");
	}
	@Override
	public void walk() {
		System.out.println("Sindhu's walk...");
	}
	@Override
	public void breathe() {
		System.out.println("Sindhu's breathe...");
	}
	
	@Override
	public void workForWages() {
		System.out.println("Sindhu has started working now...");
		
	}
	
	@Override
	public void smile() {
		Human.super.smile();
	}
	
	
}

